List searchCategories = [
  "Shop",
  "Decor",
  "Travel",
  "Architechture",
  "Food",
  "Art",
  "Style",
  "TV & Movies",
  "Music",
  "Comics"
];

List searchImage = [
  "assets/images/avatar.jpeg",
  "assets/images/avatar.jpeg",
  "assets/images/avatar.jpeg",
  "assets/images/avatar.jpeg",
  "assets/images/avatar.jpeg",
  "assets/images/avatar.jpeg",
  "assets/images/avatar.jpeg",
  "assets/images/avatar.jpeg",
];
