class Constant {
  static String apiKey = "d61431a2fb64b6e56c6f086952e63ab6";
  static String popular = "popular";
  static String nowPlaying = "now_playing";
  static String topRated = "top_rated";
  static String upcoming = "upcoming";
}
